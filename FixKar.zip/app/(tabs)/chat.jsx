import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Dimensions, Animated, ScrollView, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Linking } from 'react-native';
import { TouchableWithoutFeedback } from 'react-native';


const { width } = Dimensions.get('window');

const ChatPage = () => {
  const [activeUserId, setActiveUserId] = useState(null);
  const [messageInput, setMessageInput] = useState('');
  const [chatHistory, setChatHistory] = useState({});
  const [searchQuery, setSearchQuery] = useState('');
  const [tabAnimation] = useState(new Animated.Value(0));
  const [modalVisible, setModalVisible] = useState(false);

  const users = [
    { id: '1', name: 'John Doe', phone: '+1234567890' },
    { id: '2', name: 'Jane Smith', phone: '+0987654321' },
    { id: '3', name: 'Bob Johnson', phone: '+1122334455' },
  ];

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUserSelect = (userId) => {
    setActiveUserId(userId);
    animateTabTransition();
  };

  const handleBackToUserList = () => {
    setActiveUserId(null);
  };

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      setChatHistory(prevHistory => ({
        ...prevHistory,
        [activeUserId]: [...(prevHistory[activeUserId] || []), { text: messageInput, fromProvider: true }],
      }));
      setMessageInput('');
    }
  };

  const animateTabTransition = () => {
    Animated.timing(tabAnimation, {
      toValue: 1,
      duration: 300,
      useNativeDriver: false,
    }).start(() => tabAnimation.setValue(0));
  };

  const tabAnimationStyle = {
     opacity: tabAnimation.interpolate({
      inputRange: [0, 1],
      outputRange: [1, 0.8],
    }),
  };

  const openWhatsApp = () => {
    const phone = '+917779845889';  // Number to redirect
    const message = 'Hello, I would like to connect with you.'; // Predefined message (optional)
    Linking.openURL(`whatsapp://send?phone=${phone}?body=${message}`);
    setModalVisible(false);
  };

  const makeCall = () => {
    const phone = '+917779845889';  // Number to redirect
    Linking.openURL(`tel:${phone}`);
    setModalVisible(false);
  };


  const sendTextMessage = () => {
    const phone = '+917779845889';  // Number to send the SMS
    const message = 'Hello, I would like to connect with you.'; // Predefined message (optional)
    Linking.openURL(`sms:${phone}?body=${message}`);
    setModalVisible(false);
  };
  




  return (
    <View style={styles.container}>
      {/* Top Section with Search and Mic Icon */}
      <View style={styles.topSection}>
        <View style={styles.searchContainer}>
          <Ionicons name="search-outline" size={24} color="#FF9C01" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search..."
            placeholderTextColor="#fff"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          <TouchableOpacity style={styles.iconButton}>
            <Ionicons name="mic-outline" size={24} color="#FF9C01" />
          </TouchableOpacity>
        </View>
      </View>

      {/* User List and Chat Window */}
      {activeUserId === null ? (
        <FlatList
          data={filteredUsers}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.userItem}
              onPress={() => handleUserSelect(item.id)}
            >
              <Text style={styles.userText}>{item.name}</Text>
              <TouchableOpacity
                style={styles.connectButton}
                onPress={() => setModalVisible(true)}
              >
                <Text style={styles.connectButtonText}>Connect</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          )}
        />
      ) : (
        <Animated.View style={[styles.chatContainer, tabAnimationStyle]}>
          <View style={styles.chatHeader}>
            <TouchableOpacity onPress={handleBackToUserList} style={styles.backButton}>
              <Ionicons name="arrow-back-outline" size={24} color="#FF9C01" />
            </TouchableOpacity>
            <Text style={styles.chatHeaderText}>
              {users.find(user => user.id === activeUserId)?.name}
            </Text>
          </View>
          <ScrollView contentContainerStyle={styles.messageList}>
            {chatHistory[activeUserId]?.map((message, index) => (
              <View
                key={index}
                style={[
                  styles.messageBubble,
                  message.fromProvider ? styles.providerMessage : styles.userMessage,
                ]}
              >
                <Text style={styles.messageText}>{message.text}</Text>
              </View>
            ))}
          </ScrollView>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder="Type a message..."
              placeholderTextColor="#CDCDE0"
              value={messageInput}
              onChangeText={setMessageInput}
            />
            <TouchableOpacity onPress={handleSendMessage} style={styles.sendButton}>
              <Ionicons name="send-outline" size={24} color="#FF9C01" />
            </TouchableOpacity>
          </View>
        </Animated.View>
      )}

      {/* Modal for Connect Options */}



<Modal
  animationType="slide"
  transparent={true}
  visible={modalVisible}
  onRequestClose={() => setModalVisible(false)}
>
  {/* Detect tap outside modal */}
  <TouchableWithoutFeedback onPress={() => setModalVisible(false)}>
    <View style={styles.modalContainer}>
      {/* Stop propagation inside the modal content */}
      <TouchableWithoutFeedback onPress={() => {}}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Connect Options</Text>

          {/* WhatsApp Button with Icon */}
          <TouchableOpacity onPress={openWhatsApp} style={styles.modalButton}>
            <Ionicons name="logo-whatsapp" size={24} color="#075E54" style={styles.icon} />
            <Text style={styles.modalButtonText}>WhatsApp</Text>
          </TouchableOpacity>

          {/* Call Button with Icon */}
          <TouchableOpacity onPress={makeCall} style={styles.modalButton}>
            <Ionicons name="call-outline" size={24} color="#075E54" style={styles.icon} />
            <Text style={styles.modalButtonText}>Call</Text>
          </TouchableOpacity>

          {/* Text Button with Icon */}
          <TouchableOpacity onPress={sendTextMessage} style={styles.modalButton}>
            <Ionicons name="chatbox-outline" size={24} color="#075E54" style={styles.icon} />
            <Text style={styles.modalButtonText}>Text</Text>
          </TouchableOpacity>

          {/* Close Button */}
          <TouchableOpacity onPress={() => setModalVisible(false)} style={[styles.modalButton, styles.closeButton]}>
            <Ionicons name="close-outline" size={24} color="#075E54" style={styles.icon} />
            <Text style={[styles.modalButtonText, styles.closeButtonText]}>Close</Text>
          </TouchableOpacity>
        </View>
      </TouchableWithoutFeedback>
    </View>
  </TouchableWithoutFeedback>
</Modal>




    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1E1E2C',
  },
  topSection: {
    padding: 16,
    backgroundColor: '#1E1E2C',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2C2C38',
    borderRadius: 30,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    color: '#fff',
    fontSize: 16,
  },
  iconButton: {
    paddingHorizontal: 10,
  },
  userItem: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  userText: {
    color: '#fff',
    fontSize: 18,
  },
  connectButton: {
    backgroundColor: '#FF9C01',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  connectButtonText: {
    color: '#fff',
  },
  chatContainer: {
    flex: 1,
    backgroundColor: '#2C2C38',
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#1E1E2C',
  },
  backButton: {
    marginRight: 16,
  },
  chatHeaderText: {
    color: '#fff',
    fontSize: 20,
  },
  messageList: {
    flexGrow: 1,
    padding: 16,
  },
  messageBubble: {
    padding: 10,
    borderRadius: 10,
    marginVertical: 5,
    maxWidth: '80%',
  },
  providerMessage: {
    backgroundColor: '#FF9C01',
    alignSelf: 'flex-end',
  },
  userMessage: {
    backgroundColor: '#444',
    alignSelf: 'flex-start',
  },
  messageText: {
    color: '#fff',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#1E1E2C',
  },
  input: {
    flex: 1,
    backgroundColor: '#2C2C38',
    borderRadius: 30,
    paddingHorizontal: 16,
    paddingVertical: 8,
    color: '#fff',
    marginRight: 10,
  },
  sendButton: {
    paddingHorizontal: 10,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: '#2C2C38',
    padding: 45,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 20,
    color: '#FF9C01',
    marginBottom: 20,
  },
  
    modalButton: {
      backgroundColor: '#FF9C01',
      width: 150,
      height: 40,
      borderRadius: 30,
      marginVertical: 10,
      flexDirection: 'row', // Align icon and text horizontally
      alignItems: 'center',
      justifyContent: 'center', // Align icon and text vertically
    },
    modalButtonText: {
      color: '#fff',
      fontSize: 16,
      marginLeft: 5, // Space between icon and text
    },
    icon: {
      marginRight: 5, // Add margin for spacing
    },
    closeButton: {
      backgroundColor: '#444',
    },
    closeButtonText: {
      color: '#fff',
    },
  });
  


export default ChatPage;