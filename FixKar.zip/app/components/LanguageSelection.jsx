// components/LanguageSelection.jsx
import { useRouter } from 'expo-router';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import useLanguage from '../../hooks/useLanguage'; // Adjust the path as needed
import AsyncStorage from '@react-native-async-storage/async-storage';

const languages = [
  { code: 'en', name: 'English', image: require('../../assets/images/languages/english.png') },
  { code: 'hi', name: 'हिन्दी', image: require('../../assets/images/languages/hindi.png') },
  { code: 'bn', name: 'বাংলা', image: require('../../assets/images/languages/bengali.png') },
  { code: 'ta', name: 'தமிழ்', image: require('../../assets/images/languages/tamil.png') },
  { code: 'te', name: 'తెలుగు', image: require('../../assets/images/languages/telugu.png') },
  { code: 'pa', name: 'ਪੰਜਾਬੀ', image: require('../../assets/images/languages/punjabi.png') },
];

const LanguageSelection = () => {
  const router = useRouter();
  const { setLanguage } = useLanguage();

  const handleLanguageChange = async (lng) => {
    await AsyncStorage.setItem('user-language', lng);
    setLanguage(lng);
    router.replace('/components/Landing/Landing'); // Navigate to the main screen after selection
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Select Language</Text>
      <View style={styles.cardContainer}>
        {languages.map(({ code, name, image }) => (
          <TouchableOpacity key={code} onPress={() => handleLanguageChange(code)} style={styles.card}>
            <Image source={image} style={styles.image} />
            <Text style={styles.cardText}>{name}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FAF8F7',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  cardContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  card: {
    width: 100,
    height: 120,
    backgroundColor: '#FFF',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 3,
    margin: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: 50,
    height: 50,
    marginBottom: 5,
  },
  cardText: {
    fontSize: 16,
    textAlign: 'center',
  },
});

export default LanguageSelection;
