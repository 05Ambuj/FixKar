/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(auth)` | `/(auth)/LogIn` | `/(auth)/OtpVerification` | `/(auth)/SignUp` | `/(tabs)` | `/(tabs)/chat` | `/(tabs)/dashboard` | `/(tabs)/profile` | `/(tabs)/services` | `/LogIn` | `/OtpVerification` | `/SignUp` | `/_sitemap` | `/chat` | `/components/AddService` | `/components/Landing/CustomButton` | `/components/Landing/Dot` | `/components/Landing/Landing` | `/components/Landing/Pagination` | `/components/Landing/RenderItem` | `/components/LandingService` | `/components/LanguageSelection` | `/components/Pagination` | `/components/editService` | `/dashboard` | `/profile` | `/profile/AboutUs` | `/profile/ContactUs` | `/profile/MyProfile` | `/profile/ProfileDetails` | `/profile/WorkReport` | `/services`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
