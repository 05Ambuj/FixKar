// i18n.jsx
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import AsyncStorage from '@react-native-async-storage/async-storage';
import en from './locales/en.json';
import hi from './locales/hi.json';
import bn from './locales/bn.json'; // Bengali
import ta from './locales/ta.json'; // Tamil
import te from './locales/te.json'; // Telugu
import pa from './locales/pa.json'; // Punjabi

const loadLanguage = async () => {
  const language = await AsyncStorage.getItem('user-language');
  return language || 'en'; // Default to English if no language is set
};

const initI18n = async () => {
  const lng = await loadLanguage();

  i18n
    .use(initReactI18next)
    .init({
      resources: {
        en: { translation: en },
        hi: { translation: hi },
        bn: { translation: bn }, // Bengali
        ta: { translation: ta }, // Tamil
        te: { translation: te }, // Telugu
        pa: { translation: pa }, // Punjabi
      },
      lng, // Set the loaded language as default
      fallbackLng: 'en',
      interpolation: {
        escapeValue: false,
      },
    });
};

initI18n();

export default i18n;
